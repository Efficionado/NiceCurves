//
//  IntroLayer.h
//  NiceCurves
//
//  Created by Hansy on 8/3/13.
//  Copyright Snowtygar Productions 2013. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// NiceCurvesLayer
@interface IntroLayer : CCLayer
{
}

// returns a CCScene that contains the NiceCurvesLayer as the only child
+(CCScene *) scene;

@end
